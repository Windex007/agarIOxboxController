AgarIo Xbox360 Controller
By: Windex007

This is a program that lets ME use an xbox360 controller to play agarIO
If YOU can use it to play with an xbox360 controller, that's sweet go hard, but I didn't make it for
you I made it for me. I expended about 30 seconds worth of effort to make this thing user friendly,
so set your expectations accordingly.

Also, if it straight up doesn't work for you, there is about a 0% chance I'll do anything to help,
BUT, I've made the source available on github so if you have the skills or know someone who does,
feel free to fork the repo and try and get it working. Send me a pull request if you think you've done
something good.

https://github.com/Windex007/agarIOxboxController

To Use:

-Make sure you've got an xbox360 controller plugged in. I use a wired controller, so that's all
 I've tested this with. It might work with the wireless kit but I don't really know. This program
 assumes the controller is set up as player 1.

-Start the program. As soon as you hit "Start" (or press "A") it's going to hijack your mouse.

-You can press "A" to toggle between if it's on or not. You can also HOLD "Y" to temporarily suspend
the hijacking of your mouse if you need it for something (like firing up the game).

-Get into the game. You'll want to play in full screen (or make sure that the center of your little
dude is centered on your screen) for the directions to really be dialed in. There is no calibration feature so deal with it.

-Move your dude around with the right thumbstick. Split with the right BUMPER,
 eject mass with the left BUMPER.

-When you're done, close the program. Remember to press "A" or hold "Y" so that you can use your mouse
 to close it.

NOTE:

 If you accedentally unplug your controller, just plug it back it. It should automatically find it
 again.
